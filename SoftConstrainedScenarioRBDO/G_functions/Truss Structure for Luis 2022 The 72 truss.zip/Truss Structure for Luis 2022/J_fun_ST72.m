function [WeightTruss]=J_fun_ST72(d,D)


%% Inputs:%
% D=Data72; defines the truss geometry, connectivity, etc

% delta(1:12) Loads uniformly distributed arround  +- 5*10^3
% delta(13:72+12) E modulus distributed arround 10^7
%% Output:
% WeightTruss: The weight of the truss \propto its volume and cost 
%(often used as objective function to be minimized)

ConDesign=d;%  % design (section area for each group of elements)
 for J=1:size(D.Group,1)
    Design(D.Group{J},:)=ConDesign(J);
 end

D.A=Design; % the truss design is given by the area of the identical elements
w=size(D.Re);
S=zeros(3*w(2));
U=1-D.Re;
f=find(U);
WeightTruss=0;
for i=1:size(D.Con,2)
   H=D.Con(:,i);
   C=D.Coord(:,H(2))-D.Coord(:,H(1));
   Le=norm(C);
   T=C/Le;
   s=T*T';
   G=D.E(i)*D.A(i)/Le;
   Tj(:,i)=G*T;
   e=[3*H(1)-2:3*H(1),3*H(2)-2:3*H(2)];
   S(e,e)=S(e,e)+G*[s -s;-s s];
   WeightTruss=WeightTruss+Le*D.A(i)*D.RO(1);
end
end