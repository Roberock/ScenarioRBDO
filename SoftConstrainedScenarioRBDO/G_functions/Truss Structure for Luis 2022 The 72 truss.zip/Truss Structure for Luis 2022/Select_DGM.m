function Sampler_fun = Select_DGM (RandomModel)
% select data generating mecanism

if RandomModel==1 % uncertainty in the 72 E modulus and in 12 (x,y,z) components of the loads in nodes 1-4
    Sampler_fun= @(N)  [unifrnd(-5*10^3,5*10^3,[N,12]) normrnd(0,10^5,[N,72])];
elseif RandomModel==2 % uncertainty in the 72 E modulus and in 6 components of the loads in nodes 1-4
    Sampler_fun= @(N)  [normrnd(5*10^3,500,[N,6]) normrnd(0,10^5,[N,72])];
elseif RandomModel==3 % uncertainty in the load at node 1 (x,y,z) and Areas...
    Sampler_fun= @(N) [normrnd(5*10^3,50,[N,3]) unifrnd(-0.01,0.01,[N,72])];
elseif RandomModel==4 % uncertainty in six loads, E modulus and Area...
    Sampler_fun= @(N) [normrnd(5*10^3,10,[N,6]) normrnd(0,10^3,[N,72]) unifrnd(-0.01,0.01,[N,72])];
end

end