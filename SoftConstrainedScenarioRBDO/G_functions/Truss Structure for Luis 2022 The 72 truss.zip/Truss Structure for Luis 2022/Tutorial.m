clc
clear variables
close all
%% The 72-bar four level skeletal tower 

% load data
D = Data72; % Data structure...Define the truss data geometry,connectivity, etc....

% Uncertain Scenarios 
DGM_idx=1; % select model for the uncertianty
DGM = Select_DGM(DGM_idx);

% reliability performance function and tower's cost function
g_fun = @(d,delta) g_fun_ST72(d,delta,D,DGM_idx); % requirements on displacements and tensions 
J_fun = @(design)  J_fun_ST72(design,D); % cost function (weight of the structure)
 
% design variable constraints
LBd = D.LB; % minimum area is 0.1 inces^2 for the individual truss elements
UBd = D.UB+1; % maximum area 4 inces^2 for the individual truss elements
 
% Example of optimized design % see RBMOO_E by T. Vo-Duy et al https://www.worldscientific.com/doi/abs/10.1142/S0219876219500166
d_opt=[20.64, 9.59, 2.13, 0.65, 20.65, 10.32, ...
     0.77, 0.88, 11.02, 10.52, 0.65, 0.65, 2.39, 10.36, 3.45, 5.18]*0.155;  

 %  load('Designs_72truss.mat') check this for more design vectors 

%% START!!!

% Sample N data points
N=5e3; % number of samples
delta=DGM(N);

% Test performance
g= g_fun(d_opt, delta);
Weight=J_fun(d_opt);

% visualize some of the g scores
gplotmatrix(g(:,[1:8:end]),[],max(g,[],2)>0,'br')
  