function [G_scores]=g_fun_ST72(d,delta,D,RandomModel)
%% Summary
% % % % INPUT % % % % 
% d: design variable (vector with the areas of the 16 identical beams in the 72 beams tower)
% delta: uncertain factors ()
% D: data structure with the truss information
% RandomModel: The uncertainty model selected 
%     -1  uncertainty in the 72 E modulus and in 12 (x,y,z) components of the loads in nodes 1-4
%     -2  uncertainty in the 72 E modulus and in 6 components of the loads in nodes 1-4
%     -3  uncertainty in the load at node 1 (x,y,z) and Areas...
%     -4  uncertainty in six loads, E modulus and Area...

% % % % Output % % % % 
% G scores

%% START

N = size(delta,1);
for J=1:size(D.Group,1)
    Design(D.Group{J},:)=d(J);  % design j (section area for each group of elements indexed by j)
end
Emodulus=D.E; % Modulus of Elasticity for the 72 elements

G_scores = zeros(N,84);

for i=1:N % for each sample do
    
    if RandomModel==1 % Uncertainty model 1:
        D.LoadCase_rnd(:,17:20)=reshape(delta(i,1:12),3,4);
        D.E=Emodulus+ delta(i,12+1:end)';
    
    elseif RandomModel==2 % Uncertainty model 2:
        D.LoadCase_rnd(:,17:20)=reshape(delta(i,1:12),3,4);
        D.LoadCase_rnd=zeros(3,20);
        D.LoadCase_rnd(3,17:20)=-1*delta(i,1:4); % load peaked arround -5 [kips] (22.241 [kN])
        D.LoadCase_rnd(1:2,17)=delta(i,5:6);% load peaked arround +5 [kips]
        D.E=Emodulus+ delta(i,7+1:end);
        
    elseif RandomModel==3 % Uncertainty model 3: uncertain area and load in node 1
        D.LoadCase_rnd(:,20)=[delta(i,1)  -delta(i,2)  -delta(i,3)]; 
        Design=Design+delta(i,4:end)';
    
    elseif RandomModel==4 % Uncertainty model4: uncertain area, E modulus and loads
        D.LoadCase_rnd(:,17:20)=reshape(delta(i,1:12),3,4);
        D.LoadCase_rnd=zeros(3,20);
        D.LoadCase_rnd(3,17:20)=-1*delta(i,1:4); % load peaked arround -5 [kips] (22.241 [kN])
        D.LoadCase_rnd(1:2,17)=delta(i,5:6);% load peaked arround +5 [kips]
        D.E=Emodulus + delta(i,7:78);
        Design=Design+delta(i,79:end)';
    end
    
    % Solver
    [~,~,G_scores(i,:)]=ST72(Design,D); 
  
    
end
end